#a = t[6]
for a in range(0,10):
    for b in range(0,10):
        if ( (((b + (a*b/10) ) / 10) == 0) and (((8 + (a*8/10)) / 10) == 0) ):
            M0 = a * b % 10
            M1 = b + ( a*b/10 )
            t0 = M1 - ( (M1/10) *5 *2 )
            M01 = a*8 % 10
            M11 = 8 + (a*8/10)
            t1 = (M11 - ((M11/10)*5*2)) + M0
            if ((t1 > M0) and (t1 < 10)):
                print str(t0)+str(t1)+str(a)+str(b)+str(M0)+str(M1)+'('+str(M01)+str(M11)+')'
                print '******************************************'
