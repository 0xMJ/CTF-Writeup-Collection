

a='\xEB\x08BCTFOSLD'
b='\xDA\x3B\x71\x74'
i=0
for x in b:
    print chr(ord(x) ^ ord(a[i])),
    i+=1
