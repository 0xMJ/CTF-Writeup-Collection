def xor(index,d):
    i=index
    out=''
    for x in d:
        out+=chr(ord(x)^ ord('R') ^ i)
        i+=1
    return out

data=[]
for x in range(1,7):
    data.append(open('data'+str(x),'rb').read())
    

out=''
out+=xor(0,data[0])
out+=xor(0x1A,data[3])
out+=xor(0x1A*2,data[4])
out+=xor(0x1A*3,data[2])
out+=xor(0x1A*4,data[1])
out+=xor(0x1A*5,data[5])

print repr(out)
